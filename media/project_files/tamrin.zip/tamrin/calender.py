import tkinter as tk

def btn_click(number):
    current = entry.get()
    entry.delete(0, tk.END)
    entry.insert(0, current + str(number))

def btn_clear():
    entry.delete(0, tk.END)

def btn_add():
    first_number = entry.get()
    global f_num
    global math_operation
    math_operation = "addition"
    f_num = float(first_number)
    entry.delete(0, tk.END)

def btn_subtract():
    first_number = entry.get()
    global f_num
    global math_operation
    math_operation = "subtraction"
    f_num = float(first_number)
    entry.delete(0, tk.END)

def btn_multiply():
    first_number = entry.get()
    global f_num
    global math_operation
    math_operation = "multiplication"
    f_num = float(first_number)
    entry.delete(0, tk.END)

def btn_divide():
    first_number = entry.get()
    global f_num
    global math_operation
    math_operation = "division"
    f_num = float(first_number)
    entry.delete(0, tk.END)

def btn_equal():
    second_number = entry.get()
    entry.delete(0, tk.END)
    if math_operation == "addition":
        result = f_num + float(second_number)
    elif math_operation == "subtraction":
        result = f_num - float(second_number)
    elif math_operation == "multiplication":
        result = f_num * float(second_number)
    elif math_operation == "division":
        if float(second_number) == 0:
            result = "خطا: تقسیم بر صفر"
        else:
            result = f_num / float(second_number)
    entry.insert(0, result)

# ایجاد پنجره اصلی
window = tk.Tk()
window.title("ماشین حساب ساده")

# ورودی عدد
entry = tk.Entry(window, width=16, font=("Arial", 24), bd=2, relief="ridge", justify='right')
entry.grid(row=0, column=0, columnspan=4)

# دکمه‌ها
button_texts = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('+', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('-', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('*', 3, 3),
    ('0', 4, 0), ('C', 4, 1), ('=', 4, 2), ('/', 4, 3),
]

for (text, row, col) in button_texts:
    if text.isdigit():
        action = lambda x=text: btn_click(x)
    elif text == 'C':
        action = btn_clear
    elif text == '+':
        action = btn_add
    elif text == '-':
        action = btn_subtract
    elif text == '*':
        action = btn_multiply
    elif text == '/':
        action = btn_divide
    elif text == '=':
        action = btn_equal
    btn = tk.Button(window, text=text, width=5, height=2, font=("Arial", 20), command=action)
    btn.grid(row=row, column=col)

# اجرای برنامه
window.mainloop()